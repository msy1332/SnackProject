﻿// //窗口
// #define EX_SHOWCONSOLE		1   //显示控制台窗口
// #define EX_NOCLOSE			2   //禁用关闭按钮
// #define EX_NOMINIMIZE		4   //禁用最小化按钮
// #define EX_DBLCLKS			8   //支持鼠标的双击事件



//头文件
#include <windows.h>
#include <iostream>
#include <stdlib.h>
#include <cstdio>
#include <easyx.h>
#pragma once

class Window_Api
{
    public:
        int width;//窗口的宽度
        int height;//窗口的高度
        int flag=0;//窗口的设置
        COLORREF Bkcolor;//颜色
        Window_Api();//构造函数
        ~Window_Api();//析构函数
        void Create_Window();//创建窗口
        void Clear_Window();//清屏
        void Close_Window();//关闭窗口
        void Set_Bkcolor();//设置背景颜色
        // void Set_Bkcolor(COLORREF Bkcolor);//设置背景颜色
        // void Set_Bkcolor(int R,int G,int B);//设置背景颜色
    private:
    protected:
};