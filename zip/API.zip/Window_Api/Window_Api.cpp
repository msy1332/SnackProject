﻿#include "Window_Api.h"
#include <easyx.h>      //包含easyx图形库头文件
Window_Api::Window_Api()//构造函数
{

}

Window_Api::~Window_Api()//析构函数
{

}

void Window_Api::Create_Window()
{
    initgraph(this->width,this->height,this->flag);//创建窗口
}

void Window_Api::Set_Bkcolor()
{
    setbkcolor(this->Bkcolor);//设置背景颜色
}

void Window_Api::Close_Window()
{
    closegraph();//关闭窗口
}

void Window_Api::Clear_Window()
{
    cleardevice();//这个函数使用当前背景色清空绘图设备。
}

/*
    void Window_Api::Set_Bkcolor(COLORREF Bkcolor)
    {
        setbkcolor(Bkcolor);//设置背景颜色
    }
    void Window_Api::Set_Bkcolor(int R,int G,int B)
    {
        setbkcolor(RGB(R,G,B));//设置背景颜色
    }
*/