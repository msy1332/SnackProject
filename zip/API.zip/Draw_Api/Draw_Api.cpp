#include "Draw_Api.h"
#include <windows.h>
#include <easyx.h>
Draw_Api::Draw_Api()
{
    
}

Draw_Api::~Draw_Api()
{

}

void Draw_Api:: Draw_Line(int x1,int y1,int x2,int y2)
{
    line(x1,y1,x2,y2);
}

void Draw_Api::Draw_Pixel(int x,int y,COLORREF color)
{
    putpixel(x,y,color);
}

void Draw_Api::Draw_Rectangle(int left, int top, int right, int bottom)
{
    rectangle(left,top,right,bottom);
}

void Draw_Api::Draw_Fill_Rectangle(int left, int top, int right, int bottom)
{
    fillrectangle(left,top,right,bottom);
}

void Draw_Api::Draw_Solid_Rectangle(int left, int top, int right, int bottom)
{
    solidrectangle(left,top,right,bottom);
}

void Draw_Api::Draw_RoudRect(int left, int top, int right, int bottom, int ellipsewidth, int ellipseheight)
{
    roundrect(left,top,right,bottom,ellipsewidth,ellipseheight);
}

void  Draw_Api::Set_Line_Color(COLORREF color)
{
    setlinecolor(color);
}

void  Draw_Api::Set_Fill_Color(COLORREF color)
{
    setfillcolor(color);
}

void Draw_Api::Begin_BatchDraw()
{
    BeginBatchDraw();
}

void Draw_Api::End_BatchDraw()
{
    EndBatchDraw();
}