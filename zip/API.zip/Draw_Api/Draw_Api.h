//头文件
#include <windows.h>
#include <iostream>
#include <stdlib.h>
#include <cstdio>
#include <easyx.h>

class Draw_Api
{
    public:
        Draw_Api();
        ~Draw_Api();
        void Begin_BatchDraw();
        void End_BatchDraw();
        void Set_Line_Color(COLORREF color);
        void Set_Fill_Color(COLORREF color);
        void Draw_Line(int x1,int y1,int x2,int y2);
        void Draw_Pixel(int x,int y,COLORREF color);
        void Draw_Rectangle(int left, int top, int right, int bottom);
        void Draw_Fill_Rectangle(int left, int top, int right, int bottom);
        void Draw_Solid_Rectangle(int left, int top, int right, int bottom);
        void Draw_RoudRect(int left, int top, int right, int bottom, int ellipsewidth, int ellipseheight);
    private:
    protected:
};