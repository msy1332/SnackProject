#include "Image_Api.h"
Image_Api::Image_Api()
{
    
}

Image_Api::~Image_Api()
{

}

void Image_Api::Put_Image(int x,int y,IMAGE *pDstImg)
{
    putimage(x,y,&pDstImg);
}

// void Image_Api::Put_Image(int dstX, int dstY, int dstWidth, int dstHeight,IMAGE *pSrcImg)
// {
//     putimage(dstX, dstY, dstWidth, dstHeight,&pSrcImg);
// }

void Image_Api::Transparency_Map()
{

}

// void Image_Api::Transparency_Map()
// {

// }

void Image_Api::Init_Image(LPCTSTR pImgFile)
{

}
void Image_Api::Load_Image(IMAGE *pDstImg, string pImgFile)
{
    loadimage(&pDstImg,pImgFile.c_str());
}