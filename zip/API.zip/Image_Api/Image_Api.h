#include <iostream>
#include <windows.h>
#include <easyx.h>
#include <vector>
#include <string>

class Image_Api
{
    public:
        Image_Api();
        ~Image_Api();
        // void Load_Image(IMAGE *pDstImg, LPCTSTR pImgFile);
        // void Put_Image(int x,int y,IMAGE *pDstImg);
        // void Init_Image(LPCTSTR pImgFile);
        // void Transparency_Map();
        void 
    private:
        vector<IMAGE> img;
    protected:
};